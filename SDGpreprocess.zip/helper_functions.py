import itertools
from sklearn.preprocessing import MinMaxScaler, StandardScaler, RobustScaler, LabelEncoder,OneHotEncoder
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split,cross_val_score
from sklearn.metrics import mean_squared_error
from collections import Counter
from scipy.stats import ttest_rel, shapiro, mannwhitneyu
import string
from datetime import datetime
import pandas as pd
import pprint
import os
from glob import glob
import numpy as np
import json
from tabulate import tabulate
import re
import math
import ast
from functools import reduce
from argparse import ArgumentParser
import seaborn as sns
import matplotlib.pyplot as plt

# a generator object to return multiple combinations
def generate_combinations(x):
    f, d = [], []
    attrs = list(set([i[0] for i in x]))
    for i in attrs:
        for j in x:
            if (j[0] == i):
                f.append((i, j[1]))
        g = f.copy()
        d.append(g)
        f.clear()

    combinations = list((itertools.product(*d)))
    return combinations

# returns columns in a dataframe that atleast have a single filled value and not completely empty with Nan's
def fetch_parameters_for_auto_arima(data):
    data = data.replace('None', np.NaN)
    attr_parameters = [attr for attr in data if (data[attr].isnull().sum() != len(data[attr]))]
    return attr_parameters


def re_scale(df, scaling_method=None):
    if scaling_method == 'standard':
        scaler = StandardScaler(with_mean=False)
    elif scaling_method == 'minmax':
        scaler = MinMaxScaler()
    elif scaling_method == 'robust':
        scaler = RobustScaler()
    else:
        raise ValueError(scaling_method, 'Sorry, use either one of these minmax, standard or robust')

    # scaled = pd.DataFrame(scaler.fit_transform(df.values), index=df.index, columns=list(df.columns))

    scaled = pd.DataFrame()
    # print(tabulate(df, headers='keys', tablefmt='psql'))
    for v in df:
        print(df[v].values.reshape(-1,1))
        n = pd.DataFrame(df[v], columns=[v])
        if v != 'ds':
            n = scaler.fit_transform(df[v].values.reshape(-1, 1))
            n = pd.DataFrame(n, columns=[v])
        scaled = pd.concat([scaled, n], axis=1)
        print(scaled)
    # print(tabulate(scaled, headers='keys', tablefmt='psql'))
    scaled.index = df.index
    return scaler, scaled

def interpolate(df, scaling_method=None):
    if scaling_method == 'standard':
        scaler = StandardScaler(with_mean=False)
    elif scaling_method == 'minmax':
        scaler = MinMaxScaler()
    elif scaling_method == 'robust':
        scaler = RobustScaler()
    else:
        raise ValueError(scaling_method, 'Sorry, use either one of these minmax, standard or robust')

    scaled = pd.DataFrame()
    # print(tabulate(df, headers='keys', tablefmt='psql'))
    for v in df:
        #print(df[v].values.reshape(-1,1))
        n = pd.DataFrame(df[v], columns=[v])
        if v != 'ds':
            n = scaler.fit_transform(df[v].values.reshape(-1, 1))
            n = pd.DataFrame(n, columns=[v])
        scaled = pd.concat([scaled, n], axis=1)
    # print(tabulate(scaled, headers='keys', tablefmt='psql'))
    scaled.index = df.index
    return scaler, scaled


#obtaining datetime object for the date in the time series
def obtain_date(x):
    x = datetime.strptime(x, '%Y')
    return x

# tansforming series description by ordering the duplicate series giving them a count from 0 to n (n-total number of duplicates per seriesdescription)
def label_encod(elem):
    unique_series = list(Counter(elem).keys())
    unique_series = [str(i) for i in unique_series]
    encoded_list = []
    for unique_serie in unique_series:
        duplicate_series = [i for i in elem if i == unique_serie]
        duplicate_series_transformed = [str(i) + '__' + str(j) for j, i in enumerate(duplicate_series)]
        for i in duplicate_series_transformed:
            encoded_list.append(i)
        duplicate_series.clear()
    return encoded_list


def label_decode(elem):
    decoded_list = []
    for item in elem:
        split_item = item.split('__')
        decoded_list.append(split_item[0])
    return decoded_list


def one_encod(elem):
    o_encod = OneHotEncoder()
    return o_encod.fit_transform(elem)

def convert_strings_to_floats(x):
    if x == 'None':
        return x
    elif (type(x) == str):
        if not (x.__contains__('>')):
            return float(x.replace(',', ''))
        else:
            return x
    elif (type(x) == float or type(x) == int):
        return float(x)
    else:
        return x

#encode the series description names in
def query_for_series_code(org_file):

    #look through current director for all sub-directories assuming every sub-directory belongs to a country
    current_country_dirs = list(dir for dir in os.listdir('../SDGS/') if os.path.isdir(dir))
    #escape sub-directories the likes of '.git', '__pycache__' and many others
    current_country_dirs = [i for i in current_country_dirs if not re.search(r'\.|\_', i, re.IGNORECASE)]
    #open each sub-directory
    for i, country in enumerate(current_country_dirs):
        new_data = []
        #pick only json files, because they're all you want to encode
        json_fname = glob(os.path.join(os.path.abspath(country), '*.json'))
        if json_fname:
            json_file_list = [i for i in json_fname if i.__contains__('series')]
            json_file = json_file_list[0]
            json_dir_file = os.path.dirname(json_file)
            with open(json_file, 'r') as rb:
                org = pd.read_csv(org_file, low_memory=False)
                country_org = org[org['GeoAreaName'] == country]
                org_of_interest = country_org[['Goal', 'Target', 'Indicator', 'SeriesCode', 'SeriesDescription']]
                load_file = json.load(rb)
                q = 0
                for m in load_file:
                    q+=1
                    for a,b,c,x,y in zip(org_of_interest['Goal'], org_of_interest['Target'], org_of_interest['Indicator'], org_of_interest['SeriesCode'], org_of_interest['SeriesDescription']):
                        if str(m['Series_description']).__contains__(str(y)):
                            s = m['Series_description'].split('_')
                            s = sorted(s, key=lambda x: len(x), reverse=True)

                            w = [a,b,c]
                            for d in w:
                                if d in s:
                                    s.remove(d)

                            for o in range(len(s)):
                                for t in [w.pop() for _ in range(len(w))]:
                                    if str(t).strip()[-2:] == '.0':
                                        t = str(int(t))
                                    else:
                                        t = str(t)
                                    s.insert(o+1, t)
                                    #print(s)
                                break

                            e = '_'.join(i for i in s).rstrip('_')
                            m['Series_description'] = e.replace(str(y), x)
                        else:
                            pass
                    new_data.append(m)
            with open(os.path.join(json_dir_file, 'encoded_TS_fb.json'), 'w') as fb:
                json.dump(new_data, fb, indent=2, sort_keys=True)
            fb.close()
            rb.close()

#query_for_series_code('allcountries.csv')

#creating a directory for the plots
def create_directories_per_series_des(name=''):
    _dir = os.path.abspath(os.path.join(os.path.curdir, name))
    if not os.path.exists(_dir):
        os.makedirs(_dir)
    return _dir

def modelling(x, y):
    X_train, x_test, Y_train, y_test = train_test_split(x, y, test_size=0.2)
    rf = RandomForestRegressor()
    rf_model = rf.fit(X_train, Y_train)
    y_pred = rf_model.predict(x_test)
    rmse = np.sqrt(-cross_val_score(rf_model, X_train, Y_train, scoring='neg_mean_squared_error', cv=10))
    prediction_error = mean_squared_error(y_test, y_pred)
    return rf_model, y_pred, prediction_error

def count_nans(x):
    x_nan_search = [math.isnan(s) for s in x]
    x_nan_count = len([i for i in x_nan_search if i == True])
    return x_nan_count

def count_zeros(x):
    x_zeros_search = [i for i in x if i == 0]
    x_zeros_count = len(x_zeros_search)
    return x_zeros_count

def count_inf(x):
    x_inf_search = [np.inf == abs(c) for c in x]
    x_inf_count = len([i for i in x_inf_search if i == True])
    return x_inf_count

def normality_test(df):
    normality_test = df.apply(lambda x: shapiro(x)[1] < 0.05)

def sort_yassir_data_columns():
    file = pd.read_csv('causality/combinations/Egypt/Egypt_goal_19.csv')
    d = file.columns
    cols = []
    for i in d:
        column_name_items = i.split('_')
        if len(column_name_items) == 2:
            cols.append(i)
        else:
            s = i.replace('_', '', 1)
            cols.append(s)
    file.columns = cols
    file.reset_index()
    file.to_csv('causality/combinations/Egypt/Egypt_goal_19.csv')

def extract_country_name_code(file, code):
    x = ''
    with open(file, 'r') as f:
        for i in json.load(f):
            if i['geoAreaCode'].strip() == code:
                x = i['geoAreaName']
                break
    return x

from pprint import pprint
def seperate_time_series_json(file):
    with open(file, 'r') as j:
        j_read = json.load(j)
        all_ts = {}
        for i in j_read:
            time_serie_name = i.split('~', 1)
            if time_serie_name[1] not in all_ts:
                all_ts[time_serie_name[1]] = {i:j_read[i]}
            else:
                if time_serie_name[1] in all_ts:
                    all_ts[time_serie_name[1]][i] = j_read[i]

        for i,ts in enumerate(all_ts):
            with open(ts+'.json', 'w') as i_out:
                json.dump(all_ts[ts], i_out, indent=3, sort_keys=True)
    j.close()

#merge several goal information
def merging_new_data_files(args):
    source = args.source
    files_to_merge = glob(source+'/*.xlsx')
    frames_to_merge = []
    for i_loc in files_to_merge:
        o = pd.read_excel(i_loc)
        frames_to_merge.append(o)
    frame_csv = pd.concat(frames_to_merge)
    dest = create_directories_per_series_des(source+'/'+os.path.basename(source))
    frame_csv.to_csv(os.path.join(dest+'/{}.csv'.format(os.path.basename(source))))

'''
pick a country name from country codes by passing it's code and changing code 
 to True otherwise, pick country code by passing country name and leaving code to False
'''
def fetch_country_or_code(country_codes, code_or_country, code=False):
    c = ''
    with open(country_codes, 'r') as v:
        for i in json.load(v):
            if code:
                if i['geoAreaCode'].strip() == code_or_country.strip():
                    c = i['geoAreaName'].lower().strip()
                    break
            else:
                if i['geoAreaName'].lower().strip() == code_or_country.lower().strip():
                    c = i['geoAreaCode'].strip()
                    break
    return c

def track_back_noisy_data_information(file, columns, source):
    file_df = pd.read_csv(file)
    noisy_info = []
    columns_d = []
    with open(columns, 'r') as c:
        for k in c.readlines():
            k = [i.strip() for i in k.split(' ', 2)]
            if k[0].strip() != 'Gaol' and k[0].strip() != 'Goal' and k[0].strip() != '\n':
                l = ast.literal_eval(str(k[-1]))
                key = 'SD_'+l['Goal']+'_'+str(int(k[0].strip("."))+1)
                columns_d.append({'key':key.strip(), 'value':l})
        for ts in file_df:
            for elem in columns_d:
                if elem['key'] == ts:
                    # print(ts, list(elem['value'].values()))
                    noisy_info.append((elem['value']['Goal'], elem['value']['Target'], elem['value']['Indicator'], elem['value']['SeriesCode'], list(elem['value'].values())[-1], 'Insufficient_for_analysis'))
                    break
        noisy_info_df = pd.DataFrame(noisy_info, columns=['Goal', 'Target', 'Indicator', 'Series Code', 'Meta data', 'Result'])
        # noisy_info_df.to_csv()
        print(tabulate(noisy_info_df, headers='keys', tablefmt='psql'))

def collate_timeseries_rmse(args):
    countries = os.listdir(args.source)
    d = []
    for ctry in countries:
        for tech_dir in os.listdir(args.source+'/'+ctry):
            for f in glob(args.source+'/'+ctry+'/'+tech_dir+'/sdgs*.json'):
                f_open = json.load(open(f, 'r'))
                for i in f_open:
                    t_serie, rmse, mape_value = i['Series_description'], i['RMSE'], i['MAPE']
                    mtd = os.path.basename(f).split('.')[0].split('_')[-1]
                    d.append([ctry, mtd, t_serie, rmse, mape_value])
    df = pd.DataFrame(np.array(d), columns=['Country', 'Forecaster', 'Time_serie', 'RMSE', 'MAPE'])
    print(df['Forecaster'])
    for forecaster in args.forecaster.split():
        forecaster_df = df.loc[df['Forecaster'] == forecaster.strip()]
        forecaster_df.to_csv(args.source+'/{}.csv'.format(forecaster))
    print(df)

def visulising_forecasts(folder, ts=None):

    for fold in os.listdir(folder):
        forecast_file = glob('{}/{}/sdgs*.json'.format(folder,fold))
        forecaster = fold.split('_')[-1]
        forecaster_df = []
        if forecast_file:
            with open(forecast_file[0], 'r') as f:
                f_Read = json.load(f)
                for i in f_Read:
                    time_serie = i['Series_description']
                    forecasted_period = i['Predicted_period']
                    forecasted = i[forecaster]
                    org = i['org_values']
                    org_period = [forecasted_period[0]-(i+1) for i in range(len(org))]
                    org_period = sorted(org_period)
                    i_f = pd.DataFrame({'Date':org_period+forecasted_period, time_serie:org+forecasted})
                    # i_f.set_index('Date', inplace=True)
                    forecaster_df.append(i_f)
        if forecaster_df:
            forecaster_df = reduce(lambda df1,df2: pd.merge(df1,df2,on='Date'), forecaster_df)
            forecaster_df.set_index('Date', inplace=True)
            if ts:
                if ts in forecaster_df.columns:
                    fig, ax = plt.subplots()
                    sns.lineplot(data=forecaster_df, x=forecaster_df.index, y=ts)
                    plt.xticks(forecaster_df.index, rotation=90)
                    ax.spines['top'].set_visible(False)
                    ax.spines['right'].set_visible(False)
                    plt.show()
        forecaster_df.to_csv('{}/{}/{}.csv'.format(folder, fold, forecaster))


if __name__ == '__main__':
    par = ArgumentParser()
    par.add_argument('--source', type=str, default='new_data_7_countries', help='source fo data to manipulate')
    par.add_argument('--function', type=str, required=True, help='function to execute')
    par.add_argument('--forecaster', type=str, default='arima', help="you can pass all methods 'arima arma lstm fb' or just one 'arima'")
    par.add_argument('--timeserie', type=str, help="name the time serie to visualize")
    args = par.parse_args()
    if args.function == 'merge':
        merging_new_data_files(args)
    elif args.function =='collate_timeseries_rmses':
        collate_timeseries_rmse(args)
    elif args.function == 'visualising_forecasts':
        visulising_forecasts(args.source, ts=args.timeserie)
    # seperate_time_series_json('causality/ctry_combinations/8_20/output/pca_output/causality.json')
    # track_back_noisy_data_information('causality/countries/germany/original_data/germany_noisy_time_series.csv',
    #                                   'causality/countries/germany/column_names.txt',
    #                                   'all_countries.csv')