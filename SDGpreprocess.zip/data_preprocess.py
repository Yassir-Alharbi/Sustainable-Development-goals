import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import fetch_data as fd
from sklearn.preprocessing import LabelEncoder, OneHotEncoder, MinMaxScaler
from collections import Counter
import json
from tabulate import tabulate
import pprint
import helper_functions as hf
import os
import seaborn as sns
from argparse import ArgumentParser
sns.set_style("darkgrid")
pd.options.mode.chained_assignment = None

class data_preprocessing:
    def __init__(self, args):
        self.path = args.data
        self.file = pd.read_csv(self.path, low_memory=False)
        self.args = args
        self.args.plot_dir = 'Thesis_PLOTS'
        hf.create_directories_per_series_des(self.args.plot_dir)
        # GOAL, TARGET, INDICATOR and SERIES_CODE STORED SOMEWHERE FOR FUTURE USE
        #self.dataset_future = self.file[['Goal', 'Target', 'Indicator', 'SeriesCode']]

    def clean_cols(self):
        # checkout the statistics of the data
        dataset = self.file

        # cleaning up the columns
        cleaned_columns = []
        for i in dataset.columns:
            i = str(i).strip('[]')
            cleaned_columns.append(i)
        dataset.columns = cleaned_columns

        # convert the dates into one dtatype i.e string format and pick out string representing the date
        dataset['TimePeriod'] = dataset['TimePeriod'].astype(str).apply(lambda x: x[0:4])
        dataset['TimePeriod'] = pd.to_datetime(dataset['TimePeriod'], infer_datetime_format=True)
        dataset['Year'] = dataset['TimePeriod'].apply(lambda x: x.year)

        print('Number of columns before {}'.format(len(dataset.columns)))
        print('Columns:\n{}'.format(dataset.columns))
        #
        # 'Time_Detail', 'Source', 'FootNote', 'Name of international agreement',
        #  'Reporting Type', 'Nature' are un-necessary because they contain
        #  completely irrelvant infoirmation for analysis and 'TimePeriod' was replaced by Year
        #
        # print(tabulate(dataset.head(), headers='keys', tablefmt='psql'))
        columns_to_delete = [i for i in dataset.columns if i.lower().strip() in ['time_detail', 'source', 'footnote', 'reporting type', 'nature', 'timeperiod', 'upperbound', 'lowerbound', 'geoareacode']]
        a_dataset = drop_cols(dataset, columns_to_delete)
        print('Number of columns After {}'.format(len(a_dataset.columns)))
        #first action on missing values in my dataset
        a_dataset = deal_with_empty_columns(a_dataset, save_dir=None)

        #section action on missing values
        a_dataset = deal_with_empty_rows(a_dataset)

        #second action of dealing with missing values
        categorical_attributes = a_dataset.dtypes[a_dataset.dtypes == object]
        numerical_attributes = a_dataset.dtypes[a_dataset.dtypes != object]
        with open(self.args.plot_dir+'/data_preprocessing_details', 'w') as dtps:
            dtps.write('Variables\n{}\n'.format(dataset.columns))
            dtps.write("Un-necessary and Irrelevant variables include\n /"
                       "Time_Detail, Source, FootNote, Name of international agreement, Reporting Type and Nature \n /"
                       "TimePeriod was replaced by Year\n"
                     )
            dtps.write('Categorical Attributes\n{}\n'.format(categorical_attributes.index))
            dtps.write('Numerical attributes\n{}\n'.format(numerical_attributes.index))
            dtps.close()

        #Observations per year (indirectly showing missing values per year)
        g = a_dataset[['Year', 'Value']]
        print(g.head())
        g_count = g.groupby(['Year'])['Value'].count().reset_index()
        print(g_count)
        # sns.barplot(x='Year', y='Value', data=g_count)
        # plt.title('Number of observations per year')
        # plt.xticks(rotation='vertical')
        # plt.ylabel('')
        # plt.savefig(self.args.plot_dir + '/Number_of_observations_per_year.png')
        # plt.show()

        #Variability based on unit information
        print(tabulate(a_dataset.head(), headers='keys', tablefmt='psql'))
        h = a_dataset[['Year', 'Value', 'Units']]
        h_count = h.groupby(['Units'])['Value'].count().reset_index()
        print(h_count)
        # sns.barplot(x='Units', y='Value', data=h_count)
        # plt.xticks(rotation='vertical')
        # plt.title('Number of observations per Unit')
        # plt.savefig(self.args.plot_dir + '/Number of observations per Unit.png')
        # plt.show()

        h_pivot = h.pivot(columns='Units', values='Value')
        print(h_pivot)
        # print([i for i in g.Value if str(i).__contains__('<') or str(i).__contains__('>')])
        # g['Value'] = [i.replace(',','') if type(i) == str else i for i in g['Value']]
        # p = []
        # for x,y in zip(g['Year'], g['Value']):
        #     try:
        #         p.append((x,float(y)))
        #     except Exception as e:
        #         print(y, e)
        # p_frame = pd.DataFrame(p, columns=['Year', 'Value'])
        # p_frame = p_frame[p_frame['Year'] > 1999]
        # p_frame['Value'] = MinMaxScaler(feature_range=(0,100)).fit_transform(p_frame[['Value']])
        # plt.scatter(x=p_frame['Year'], y=p_frame['Value'])
        # plt.savefig(args.plot_dir + '/Data_Variability_for_various_years.png')
        # plt.show()

        for y in h_pivot:
            if type(y) == str:
                print(y)
                h_pivot[y] = [i.replace(',', '') if type(i) == str else i for i in h_pivot[y]]
                p = []
                for i in h_pivot[y]:
                    try:
                        p.append(float(i))
                    except Exception as e:
                        print(i, e)
                p_frame = pd.DataFrame(p, columns=[y])
                # md = n_frame.median()
                # sns.boxplot(x=y, y=n_frame, order=list(md.index))
                # sns.boxplot(x=p_frame[y])
                # print('Here is y', y)
                # plt.title('Data_Variability_for_{}'.format(y.replace('/','_')))
                # plt.savefig(self.args.plot_dir + '/Data_Variability_for_{}.png'.format(y.replace('/','_')))
                # plt.show()

        # for var in categorical_attributes.index:
        #     var = str(var)
        #     if var.strip().lower() != 'value':
        #         a_dataset[var].fillna('None_X', inplace=True)
        return a_dataset

    def reshaping(self):
        #introduce a dictionary that will hold countries with ntheir respective data
        countries = {}
        dataset_new = self.clean_cols()
        #remove columns not needed in our reshaped data i.e. ref self.dataset_future above
        #dataset_new = dataset_new.iloc[:, 4:]
        # checkpoint 1
        # repositioning the columns to clearly view the coming changes
        first_3_vars_required = ['Year', 'SeriesDescription', 'Value']
        columns_ordered_list = [var for var in list(dataset_new.columns) if var not in first_3_vars_required]
        columns_ordered_list_changed = np.concatenate((first_3_vars_required, columns_ordered_list), axis=None)

        dataset_new_cols = list(columns_ordered_list_changed)

        dataset_new = dataset_new[dataset_new_cols]

        # sorting the dataset by Year and series description
        dataset_new = dataset_new.sort_values(by=['SeriesDescription', 'Year'], ascending=True).reset_index()
        dataset_new.drop(['index'], inplace=True, axis=1)

        reshaped_dir = hf.create_directories_per_series_des('reshaped_countries')
        for country in set(dataset_new['GeoAreaName']):
            dataset_new_country = pd.DataFrame()
            dataset_new_pivot = pd.DataFrame()
            dataset_new_country = dataset_new.loc[dataset_new['GeoAreaName'] == country]
            dataset_new_country.to_csv(os.path.join(reshaped_dir, '{}.csv'.format(country)))

            #Process of reshaping
            # begin by reating unique values in series description, i.e. no single entry should appear more than once in this column
            dataset_new_country['SeriesDescription'] = label_encod(dataset_new_country['SeriesDescription'].astype(str))

            #then freeze all the columns we want as index columns
            index_cols = np.array(dataset_new_country.columns).tolist()
            index_cols = [col for col in index_cols if col != 'Value']

            dataset_new_country.set_index(index_cols, inplace=True)

            #then unstack to obtain a new shape of the dataset
            dataset_new_pivot = dataset_new_country.unstack('Year').reset_index()
            dataset_new_pivot['SeriesDescription'] = label_decode(dataset_new_pivot['SeriesDescription'])

            #insert a reshaped frame into a dictionary
            countries[country] = dataset_new_pivot

            dataset_new_pivot.to_csv(os.path.join(reshaped_dir, '{}_reshapedafghh.csv'.format(country)))
        return countries


#deleting unnesseary colmuns
def drop_cols(df, s):
    for i in s:
        if i in df.columns:
            df = df.drop(i, axis=1)
    return df

#deleting empty columns
def deal_with_empty_columns(df, save_dir):
    df_size = df.shape[0]
    missing_data = (df.isnull().sum()/df_size)*100
    all_null = missing_data[missing_data == (df_size/df_size)*100]
    existing_null = missing_data[missing_data != 0]
    # existing_null.plot.bar()
    # plt.xticks(rotation='vertical')
    # plt.xticks(fontsize=8)
    # plt.xlabel('Variables')
    # plt.ylabel('Percentage of missing points (%)')
    # plt.title('Missing points per variable')
    # if save_dir:
    #     plt.savefig(save_dir+'/Completely_empty_variable.png')
    # plt.show()
    df = df.drop(list(all_null.index), axis=1)
    return df

#deal with empty rows
def deal_with_empty_rows(df):
    #get reed of those rows that missing points across all variables
    df = df.dropna(how='all')
    return df

# tansforming series description by ordering the duplicate series giving them a count from 0 to n (n-total number of duplicates per seriesdescription)
def label_encod(elem):
    unique_series = list(Counter(elem).keys())
    unique_series = [str(i) for i in unique_series]
    encoded_list = []
    for unique_serie in unique_series:
        duplicate_series = [i for i in elem if i == unique_serie]
        duplicate_series_transformed = [str(i) + '__' + str(j) for j, i in enumerate(duplicate_series)]
        for i in duplicate_series_transformed:
            encoded_list.append(i)
        duplicate_series.clear()
    return encoded_list


def label_decode(elem):
    decoded_list = []
    for item in elem:
        split_item = item.split('__')
        decoded_list.append(split_item[0])
    return decoded_list


def one_encod(elem):
    o_encod = OneHotEncoder()
    return o_encod.fit_transform(elem)



if __name__ == '__main__':
    par = ArgumentParser()
    par.add_argument('--data', type=str, help='what does the raw data look like')
    par.add_argument('--plot_dir', type=str, help='where to save the plots output')
    args = par.parse_args()
    dp = data_preprocessing(args)
    file = dp.file
    # print('Columns:\n{}'.format(file.columns))
    # print('Number of columns: {}'.format(len(file.columns)))
    # print('Original shape of the data: {}'.format(file.shape))
    # print('Sample data\n',tabulate(file.head(), headers='keys', tablefmt='psql'))
    dp.clean_cols(args=args)
    # dp.reshaping()


