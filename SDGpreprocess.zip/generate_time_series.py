import numpy as np
import pandas as pd
import math
import data_preprocess as dp
import helper_functions as hf
import os
import sys
import re
from tabulate import tabulate
from datetime import datetime
import matplotlib.pyplot as plt
import json
from pprint import pprint
from scipy.interpolate import splrep, splev

import argparse

pd.options.display.max_columns=40

class generate_time_series:
    def __init__(self, reshaped_df):
        self.reshaped_df = reshaped_df
        self.sd_time_series_dict = {}
        self.plot_dir = ''

    #returning the unique series description for a country
    def return_list_of_unique_series_des(self):
        sd_list = set([i for i in self.reshaped_df['SeriesDescription']])
        return sd_list

    def generate_combinations_per_series_des(self, sd_list, ctry):
        reshaped_data = self.reshaped_df.iloc[1:, :] #we do this to avoid fumbling with multi-indexed dataframe

        reshaped_data.columns = reshaped_data.columns.get_level_values(0)

        # rename the columns to suit your desired layout
        columns = np.array(reshaped_data.columns).tolist()

        years_columns = [i for i,j in enumerate(columns) if j == 'Value'] #obtaining indexes for all years as per reshaped df

        years = [s for s in range(2019, (2019-len(years_columns)), -1)] #obtaining the range of years in your frame given the current or latest year is 2019

        years = [years.pop() for _ in range(len(years))]

        columns = np.concatenate((columns[:years_columns[0]], years), axis=None)
        reshaped_data.columns = columns

        combinations_folder = hf.create_directories_per_series_des(name='COMBINATIONS_7')
        combinations_file = open(os.path.join(combinations_folder, '{} combinations.txt'.format(ctry)), 'w')
        total_list_of_combinations = []
        for sd in sd_list:
            # selecting a series description to perform time series on, selecting the most granular detail #CHECKPOINT 2
            reshaped_data_series = reshaped_data.loc[reshaped_data['SeriesDescription'] == sd]
            years_df = reshaped_data_series.iloc[:, years_columns]

            # You don't want to eliminate any single year irrespective of whether it's completely empty or not
            parameters = hf.fetch_parameters_for_auto_arima(reshaped_data_series.iloc[:, :-(len(years_columns))])

            filled_params_df = reshaped_data_series[parameters]  # dataframw with attributes that are filled in

            filled_params_df = pd.concat([filled_params_df, years_df], axis=1)

            # convert all values in selected series description into floating points
            for col in filled_params_df:
                if (col in years):
                    filled_params_df[col] = list(map(float, list(filled_params_df[col])))

            # list to contain the different unique records of attributes
            parameter_record_list = []

            for i in parameters:
                unique_attribute_record = set(list(filled_params_df[i]))
                for record in unique_attribute_record:
                    attr_record_tuple = (i, record)
                    if attr_record_tuple not in parameter_record_list:
                        parameter_record_list.append(attr_record_tuple)

            combinations = hf.generate_combinations(parameter_record_list)
            total_list_of_combinations.append(len(combinations))

            combinations_file.write('{}\n'.format(sd))
            for i in combinations:
                combinations_file.write('{}\n'.format(str(i)))
            combinations_file.write('\n')

            combinations_df = pd.DataFrame({i:combinations})
            # print('\nAttributes to be considered in the various time series prediction include \n {}'.format(parameter_record_list))
            # print(tabulate(combinations_df, headers='keys', tablefmt=''))
            # print(len(combinations))
            p = 0
            sd_time_series_dict = []
            for comb in combinations:
                # print(p+1, comb)
                time_serie_df = pd.DataFrame()
                time_serie_df = filled_params_df
                series_description_name = ''.join(j for j in ['{}±{}+^'.format(str(i[0]),str(i[1])) for i in comb if str(i[0]) != 'SeriesDescription'])

                for pair in comb:
                    col, val = pair
                    time_serie_df = time_serie_df[time_serie_df[col] == val]

                time_serie_df = time_serie_df.iloc[:, -20:]
                try:
                    for yr in time_serie_df:
                        time_serie_df[yr] = time_serie_df[yr].apply(lambda x: hf.convert_strings_to_floats(x))

                    time_serie_df_surpressed = pd.DataFrame()
                    for c in time_serie_df:
                        if all(math.isnan(i) == True for i in time_serie_df[c]):
                            time_serie_df_surpressed[c] = [np.NaN]
                        else:
                            time_serie_df_surpressed[c] = [float(time_serie_df[c].sum(skipna=True))]

                    # time_serie_df = time_serie_df.astype(float)
                    # time_serie_df = time_serie_df.stack().groupby(level=1).sum(skipna=True).reset_index().rename(columns={'index': 'Year', 0: 'Value'})
                    time_serie_df_stacked = pd.DataFrame({'Year':time_serie_df_surpressed.columns,
                                                          'Value':time_serie_df_surpressed[0:].values.reshape(time_serie_df_surpressed.shape[1])})

                    time_serie_df_stacked['Year'] = time_serie_df_stacked['Year'].apply(lambda x: datetime.strptime(x, '%Y').year)
                    #time_serie_df = time_serie_df[time_serie_df['Year'] != 2018]
                    self.sd_time_series_dict[series_description_name] = time_serie_df_stacked
                    #sd_time_series_dict.append(time_serie_df)

                    # plt.plot(range(len(time_serie_df['Year'])), time_serie_df['Value'], label=sd)
                    # plt.xlabel('year')
                    # plt.ylabel('value')
                    # plt.title(sd)
                    # plt.xticks(range(len(time_serie_df['Year'])), time_serie_df['Year'], rotation=45)
                    #plt.savefig(os.path.join(sd_dir, '{}.png'.format(file_saved)))
                    #plt.show()
                    p+=1
                except:
                    exc_type, exc_obj, exc_tb = sys.exc_info()
                    print(exc_type, exc_obj, exc_tb.tb_lineno)

        return  self.sd_time_series_dict, combinations, combinations_folder

def spline_interpolation(x):
    a = splrep(x.index, x)
    interpolated = splev(x.index, a)
    print(1, np.array(x))
    print(2, interpolated)
    return interpolated

def main(data_reshaped):
    allGoalsTimeSeries = pd.DataFrame()
    z_time_series = pd.DataFrame()
    unique_sds_in_country = data_reshaped.return_list_of_unique_series_des()

    # print('The number of Unique Series_description in {}: {}'.format(country, len(unique_sds_in_country)))
    time_seies_dict, combinations, combinations_folder = data_reshaped.generate_combinations_per_series_des(
        unique_sds_in_country, country)
    # f = data_reshaped.sd_time_series_dict
    # print(len(time_seies_dict))
    sds, sds_list = {}, []
    goals = list(range(1, 18, 1))

    for g in goals:
        for i, j in enumerate(time_seies_dict):
            r = j.strip().split('+^')
            d = [i for i in list(r) if len(i) > 0]
            d = dict([i.split('±') for i in d])
            # print(d)
            try:
                target = d['Target'].split('.')
                goal = d['Goal'].split('.')
                ind = d['Indicator'].split('.')

                if int(target[0]) == int(ind[0]) == int(goal[0]):
                    if g in goals and int(goal[0]) == g:
                        u = [(i, j) for i, j in d.items() if i not in ['Target', 'Goal', 'Indicator']]
                        for o in [('Indicator', d['Indicator']), ('Target', d['Target']), ('Goal', d['Goal'])]:
                            u.insert(0, o)
                        sds_list.append((dict(u), time_seies_dict[j]))
                    else:
                        pass
            except ValueError as e:
                print('Nothing seems to be an integer in there')
                print('Nothing seems to be an integer in there')
        sds[g] = [i for i in sds_list]
        sds_list.clear()

    with open(os.path.join(country_dir, 'column_names.txt'), 'w') as cn:
        un_found_series_codes = []
        if args.taxonomy:
            print('\n\n\n--------------------------------TAXONOMY WORKS-------------------------------\n\n\n')
            tax = pd.read_excel('taxonomy.xlsx')
            tax_series_codes = dict([[k+1, v] for k,v in tax['SeriesCode'].to_dict().items()])
            print(list(tax_series_codes)[:20])
        for k, v in sds.items():
            analysis_file = pd.DataFrame([i for i in range(2000, 2020, 1)], columns=['Year'])
            cn.write('Gaol {} \n'.format(str(k)))
            p, k_columns = 0, []
            for m, n in v:
                analysis_file = analysis_file.merge(n, on=['Year'])
                cn.writelines('{}. SD {}'.format(str(p), str(m)))
                cn.writelines('\n')
                if args.taxonomy:
                    c = '_'.join([m['SeriesCode'], m['Goal'], m['Target'],  m['Indicator'], '{}'])
                    c = c.format('_'.join([j for i,j in m.items() if i not in ['GeoAreaName', 'SeriesCode', 'Indicator', 'Target', 'Goal', 'Units']]))
                    c.rstrip('_')
                    k_columns.append(c)
                p += 1

            analysis_file_copy = analysis_file.copy()
            analysis_file_copy.columns = list(range(len(analysis_file_copy.columns)))
            analysis_file_copy.rename(columns={analysis_file_copy.columns[0]:"Year"}, inplace=True)
            analysis_file_copy.set_index('Year', inplace=True)

            if args.taxonomy:
                c = hf.fetch_country_or_code(country_codes='country_codes.json', code_or_country=country)
                found_items = []
                for o,l in enumerate(k_columns):
                    # print('L looked for', l)
                    found = False
                    for t,b in tax_series_codes.items():
                        l_, b_ = re.split('_', l.strip()), re.split('_', b.strip())
                        l_, b_ = sorted(l_), sorted(b_)
                        if '_'.join(l_) == '_'.join(b_):
                            # print('Found', l, b)
                            found_items.append((o+1, country+'_'+b.split('_')[5]+'_'+str(t)))
                            found = True
                            break
                    if not found:
                        # print('Not found Not found Not found Not found')
                        if l not in un_found_series_codes:
                            un_found_series_codes.append(l)
                if found_items:
                    analysis_file_copy_ = pd.DataFrame()
                    analysis_file_copy_columns = []
                    for o,f in found_items:
                        for u in analysis_file_copy:
                            if o == u:
                                analysis_file_copy_columns.append(f)
                                analysis_file_copy_ = pd.concat([analysis_file_copy_, analysis_file_copy[u]], axis=1)
                    analysis_file_copy_.columns = analysis_file_copy_columns
                    analysis_file_copy = analysis_file_copy_
                    analysis_file_copy_.to_csv(os.path.join(country_dir, '{}_goal_{}.csv'.format(country, k)))
                else:
                    print('\n Unfound \n', k)
            else:
                analysis_file_copy.columns = ['SD_{}_{}'.format(k, i) for i in range(1, len(v) + 1)]
                analysis_file_copy.to_csv(os.path.join(country_dir, '{}_goal_{}.csv'.format(country, k)))

            # all goals combined
            allGoalsTimeSeries = pd.concat([allGoalsTimeSeries, analysis_file_copy], axis=1)
        with open('causality/'+os.path.basename(os.path.dirname(args.data))+'/unfound_series.txt', 'w') as u_f:
            for u in un_found_series_codes:
                u_f.write('{}\n'.format(u))
            u_f.close
        cn.close()

    '''
        1. creating a directory to contain the original data
        2. Splitting the original time series into two sets, 1) having noisy time series (z_time_series), i.e. over 5 null values or 5 zeros
        and retaining the remainder set as the clean set of time series
    '''
    org_dir = hf.create_directories_per_series_des(os.path.join(country_dir, 'original_data'))
    allGoalsTimeSeries_copy = allGoalsTimeSeries.copy()
    z_items = []

    for i in allGoalsTimeSeries_copy:
        a = hf.count_nans(allGoalsTimeSeries_copy[i])
        b = hf.count_inf(allGoalsTimeSeries_copy[i])
        c = hf.count_zeros(allGoalsTimeSeries_copy[i])
        # if there are more than 5 zeros, that is noise
        if c > 2:
            z_time_series = pd.concat([z_time_series, allGoalsTimeSeries[i]], axis=1)
            z_items.append(i)
        # if there are 15 or more than 15 nans, that is noise
        if a >= 3:
            z_time_series = pd.concat([z_time_series, allGoalsTimeSeries[i]], axis=1)
            z_items.append(i)

    #allGoalsTimeSeries = dp.drop_cols(allGoalsTimeSeries, z_items)  # eliminate noisy time series
    allGoalsTimeSeries = allGoalsTimeSeries[[i for i in allGoalsTimeSeries.columns if type(i) == str]]
    # print(allGoalsTimeSeries.name, allGoalsTimeSeries.names, z_time_series.index.name)
    z_time_series.index.name = 'Year'
    print(allGoalsTimeSeries.iloc[:, :4].head(), '\n', z_time_series.iloc[:, :4].head())
    z_time_series.to_csv(os.path.join(org_dir, '{}_noisy_time_series.csv'.format(country)))
    allGoalsTimeSeries.to_csv(os.path.join(org_dir, '{}_all_goals_time_series.csv'.format(country)))

    # interpolating the time series to fill in missing values
    # method 1: time interpolation
    print('\n\n\n***************************TIME TIME TIME TIME***************************\n\n\n')
    _dir_ = hf.create_directories_per_series_des(os.path.join(country_dir, 'cleaned'))
    print(tabulate(allGoalsTimeSeries.iloc[:5, :5], headers='keys', tablefmt='psql'))
    allGoalsTimeSeries.index = pd.to_datetime(allGoalsTimeSeries.index, format='%Y')
    allGoalsTimeSeries_time = allGoalsTimeSeries.interpolate(method='time', limit_direction='both')
    allGoalsTimeSeries_time.index = allGoalsTimeSeries_time.index.map(lambda x: x.year)
    print(tabulate(allGoalsTimeSeries_time.iloc[:5, :5], headers='keys', tablefmt='psql'))
    allGoalsTimeSeries_time.to_csv(os.path.join(_dir_, '{}_all_goals_time_series.csv'.format(country)))

    # method 4: spline interpolation
    if args.spline:
        print('\n\n\n***************************SPLINE SPLIE SPLINE SPLINE***************************\n\n\n')
        spline_dir = hf.create_directories_per_series_des(os.path.join(country_dir, 'cleaned', 'spline'))
        allGoalsTimeSeries_spline = allGoalsTimeSeries.apply(lambda x: x.fillna(x.interpolate(method='linear', limit_direction='both', order=2)))
        # allGoalsTimeSeries_spline = allGoalsTimeSeries.interpolate(method='cubic', limit_direction='both', axis=0)
        # allGoalsTimeSeries_spline = allGoalsTimeSeries.apply(lambda x: spline_interpolation(x))
        # allGoalsTimeSeries_spline.set_index('Year', inplace=True)
        allGoalsTimeSeries_spline.index = allGoalsTimeSeries_spline.index.map(lambda x: x.year)
        print(tabulate(allGoalsTimeSeries_spline.iloc[:5, :5], headers='keys', tablefmt='psql'))
        allGoalsTimeSeries_spline.to_csv(os.path.join(spline_dir, '{}_all_goals_spline_series.csv'.format(country)))


if __name__=='__main__':
    par = argparse.ArgumentParser()
    par.add_argument('--data', default='thesisdata.csv', type=str, help='original file from Unicef or any other source')
    par.add_argument('--countries', type=str, help='pass [egypt, thailand] If you want to process only a few countries, in this case only egypt and thailand, otherwise all countries are processed')
    par.add_argument('--taxonomy', action='store_true', help='Taxonomy')
    par.add_argument('--plot_dir', type=str, default='PLOTS', help='where to save the plots output')
    par.add_argument('--spline', action='store_true', help='only call if you want a spline interpolation')
    args = par.parse_args()
    args.plot_dir = hf.create_directories_per_series_des(os.path.basename(os.path.dirname(args.data))+'/'+args.plot_dir)
    data_processed = dp.data_preprocessing(args).reshaping()  #this line returns multiple contries
    data_processed = {ctry.strip().lower(): data_processed[ctry] for ctry in data_processed.keys()}

    if args.countries: #an option of processing a subset of the countries
        c = [i.lower().strip() for i in args.countries.strip('[]').split(',')]
        data_processed = {ctry:data_processed[ctry] for ctry in c}
    cross_check_countries = open('countries_to_cross_check.txt', 'w')
    for country in data_processed:
        print(country)
        #if country.lower() in  ['afghanistan']:
        try:
            country_dir = hf.create_directories_per_series_des('causality/'+os.path.basename(os.path.dirname(args.data))+'/{}'.format(country.lower()))
            data_reshaped = generate_time_series(data_processed[country])
            if data_reshaped:
                main(data_reshaped=data_reshaped)
        except Exception as e:
            cross_check_countries.write('{}\nError:{}\n'.format(country, e))
            print(country, '\n',e)

    cross_check_countries.close()
